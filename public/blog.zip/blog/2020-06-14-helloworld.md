---
slug: 1
title: hello, world
date: 2020-06-14
categories:
  - 随笔
tags:
  - 随笔
---

2020 年 6 月 14 日

我的博客正式建立。

愿一切安好。