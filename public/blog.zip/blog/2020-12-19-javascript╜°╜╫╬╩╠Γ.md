---
slug: 36
title: javascript 进阶问题
date: 2020-12-19
categories: 
  - 技术
tags: 
  - js
---

Github: https://github.com/lydiahallie/javascript-questions

相当不错的一个 Github 仓库，`javascript questions` ，作者每周都会发布一些有关 javascript 的题目，虽然不难但是考察细节，刷了一会，其实一些很简单的问题，结果因为细节思考不到位直接出错。


>引用作者的话：我在我的 Instagram 上每天都会发布 JavaScript 的多选问题，并且同时也会在这个仓库中发布。

>从基础到进阶，测试你有多了解 JavaScript，刷新你的知识，或者帮助你的 coding 面试！ 